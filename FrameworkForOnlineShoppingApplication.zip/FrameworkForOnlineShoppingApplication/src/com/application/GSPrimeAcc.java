package com.application;

import com.framework.PrimeAcc;

public  class GSPrimeAcc extends PrimeAcc {


	public GSPrimeAcc(int accNo, String accNm, float charges, boolean isPrime) {
		// TODO Auto-generated constructor stub
		super(accNo, accNm, charges, isPrime);

	}

	final private static float Charges=0;

	@Override
	public void bookProduct(float n1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String toString() {
		
		return super.toString()+"GSPrimeAcc []";
	}

	@Override
	public void items(float n1) {
		// TODO Auto-generated method stub
		
	}

	
	
	 
}

		